"""Conversation support for the Yanfeng AI Task integration."""

from __future__ import annotations

from typing import Literal
import re

from homeassistant.components import conversation
from homeassistant.config_entries import ConfigEntry, ConfigSubentry
from homeassistant.const import CONF_LLM_HASS_API, MATCH_ALL
from homeassistant.core import HomeAssistant
from homeassistant.helpers import intent as intent_helper
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import CONF_PROMPT, DOMAIN, LOGGER
from .entity import YanfengAILLMBaseEntity


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up conversation entities."""
    # Only create entities for subentries, not for main config entry
    for subentry in config_entry.subentries.values():
        if subentry.subentry_type != "conversation":
            continue

        async_add_entities(
            [YanfengAIConversationEntity(config_entry, subentry)],
            config_subentry_id=subentry.subentry_id,
        )


class YanfengAIConversationEntity(
    conversation.ConversationEntity,
    conversation.AbstractConversationAgent,
    YanfengAILLMBaseEntity,
):
    """Yanfeng AI conversation agent."""

    _attr_supports_streaming = False  # ModelScope doesn't support streaming yet

    def __init__(self, entry: ConfigEntry, subentry: ConfigSubentry) -> None:
        """Initialize the agent."""
        super().__init__(entry, subentry)
        # Check subentry data for LLM_HASS_API
        llm_api_enabled = self.subentry.data.get(CONF_LLM_HASS_API, False)

        if llm_api_enabled:
            self._attr_supported_features = (
                conversation.ConversationEntityFeature.CONTROL
            )

    @property
    def supported_languages(self) -> list[str] | Literal["*"]:
        """Return a list of supported languages."""
        return MATCH_ALL

    async def async_added_to_hass(self) -> None:
        """When entity is added to Home Assistant."""
        await super().async_added_to_hass()
        conversation.async_set_agent(self.hass, self.entry, self)

    async def async_will_remove_from_hass(self) -> None:
        """When entity will be removed from Home Assistant."""
        conversation.async_unset_agent(self.hass, self.entry)
        await super().async_will_remove_from_hass()

    async def _async_handle_message(
        self,
        user_input: conversation.ConversationInput,
        chat_log: conversation.ChatLog,
    ) -> conversation.ConversationResult:
        """Handle message with three-layer processing mechanism.

        Layer 1: Intent recognition (fast response ~50-200ms)
        Layer 2: AI intent understanding (if Layer 1 fails)
        Layer 3: AI conversation (open-ended dialogue)
        """
        user_text = user_input.text
        LOGGER.debug("处理用户输入: %s", user_text)

        # ========== Layer 1: Intent Recognition (第一层：意图识别) ==========
        # Try to match built-in intents first for fast device control
        intent_result = await self._try_intent_recognition(user_input)
        if intent_result:
            LOGGER.info("✅ 第一层成功: 意图识别匹配 - %s", intent_result.intent.intent_type)
            # Convert intent response to conversation result
            response_text = intent_result.speech.get("plain", {}).get("speech", "")
            if response_text:
                # Add response to chat log
                assistant_content = conversation.AssistantContent(
                    agent_id=self.entry.entry_id,
                    content=response_text
                )
                chat_log.content.append(assistant_content)
                return conversation.async_get_result_from_chat_log(user_input, chat_log)

        LOGGER.debug("⚠️ 第一层未匹配，转到第二/三层: AI处理")

        # ========== Layer 2 & 3: AI Processing (第二/三层：AI处理) ==========
        # If intent recognition fails, fall back to AI
        # Get options from subentry data
        options = self.subentry.data

        try:
            await chat_log.async_provide_llm_data(
                user_input.as_llm_context(DOMAIN),
                options.get(CONF_LLM_HASS_API),
                options.get(CONF_PROMPT),
                user_input.extra_system_prompt,
            )
        except conversation.ConverseError as err:
            return err.as_conversation_result()

        await self._async_handle_chat_log(chat_log)

        return conversation.async_get_result_from_chat_log(user_input, chat_log)

    async def _try_intent_recognition(
        self,
        user_input: conversation.ConversationInput,
    ) -> intent_helper.IntentResponse | None:
        """Try to recognize and handle intents (Layer 1).

        This checks if the user input matches any registered intent handlers.
        Returns IntentResponse if successful, None otherwise.
        """
        user_text = user_input.text

        # Define intent patterns (simplified matching)
        # In a production system, this would use home-assistant-intents or similar
        intent_patterns = {
            "ClimateSetTemperature": [
                r"(?:请|帮我|麻烦)?(?:把|将)?(.+?)(?:调|设置|设定)(?:到|为|成)?(\d+)度",
                r"(?:请|帮我|麻烦)?(.+?)(\d+)度",
            ],
            "ClimateSetMode": [
                r"(?:请|帮我|麻烦)?(?:把|将)?(.+?)(?:调|设置|设定)(?:到|为|成)?(.+?)模式",
                r"(?:请|帮我|麻烦)?(.+?)(.+?)模式",
            ],
            "ClimateSetFanMode": [
                r"(?:请|帮我|麻烦)?(?:把|将)?(.+?)(?:风速|风量)(?:调|设置|设定)(?:到|为|成)?(.+)",
                r"(?:请|帮我|麻烦)?(?:把|将)?(.+?)(.+?)(?:风|档)",
            ],
            "CoverControlAll": [
                r"(?:请|帮我|麻烦)?(?:把|将)?(?:所有|全部)(?:的)?窗帘(.+)",
                r"(.+)(?:所有|全部)(?:的)?窗帘",
            ],
            "HassNotifyIntent": [
                r"(?:请|帮我|麻烦)?(?:创建)?通知[:：]?\s*(.+)",
                r"(?:请|帮我|麻烦)?提醒(?:我)?[:：]?\s*(.+)",
            ],
        }

        # Try to match patterns
        for intent_type, patterns in intent_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, user_text)
                if match:
                    LOGGER.debug("意图匹配: %s, 模式: %s", intent_type, pattern)
                    # Extract slots from regex groups
                    slots = self._extract_slots_from_match(intent_type, match)

                    # Try to handle the intent
                    try:
                        intent_response = await intent_helper.async_handle(
                            self.hass,
                            DOMAIN,
                            intent_type,
                            slots,
                            user_text,
                            user_input.context,
                            user_input.language,
                        )
                        return intent_response
                    except intent_helper.IntentError as err:
                        LOGGER.debug("意图处理失败: %s", err)
                        continue

        return None

    def _extract_slots_from_match(
        self,
        intent_type: str,
        match: re.Match,
    ) -> dict:
        """Extract slot values from regex match based on intent type."""
        slots = {}

        if intent_type == "ClimateSetTemperature":
            if len(match.groups()) >= 2:
                slots["name"] = {"value": match.group(1).strip()}
                slots["temperature"] = {"value": match.group(2).strip()}

        elif intent_type == "ClimateSetMode":
            if len(match.groups()) >= 2:
                slots["name"] = {"value": match.group(1).strip()}
                slots["mode"] = {"value": match.group(2).strip()}

        elif intent_type == "ClimateSetFanMode":
            if len(match.groups()) >= 2:
                slots["name"] = {"value": match.group(1).strip()}
                slots["fan_mode"] = {"value": match.group(2).strip()}

        elif intent_type == "CoverControlAll":
            if len(match.groups()) >= 1:
                slots["action"] = {"value": match.group(1).strip()}

        elif intent_type == "HassNotifyIntent":
            if len(match.groups()) >= 1:
                slots["message"] = {"value": match.group(1).strip()}

        return slots